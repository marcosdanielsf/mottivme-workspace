---
name: conversational-influence
description: Master conversational influence combining Dale Carnegie principles, No-Go sales, copywriting frameworks (AIDA, PAS), storytelling techniques, NEPQ (Neuro-Emotional Persuasion Questions), and BANT qualification. Use when optimizing SDR prompts, sales scripts, chatbot conversations, email campaigns, objection handling, or any persuasive communication requiring authentic connection and high conversion.
---

# Conversational Influence

Transform sales conversations using proven psychological principles, copywriting frameworks, and modern no-pressure techniques for authentic, high-converting communication.

## When to Use This Skill

Invoke this skill when working on:
- **SDR/Chatbot prompts** - Optimize AI sales agents for conversion
- **Sales scripts** - Craft persuasive conversation flows
- **Email campaigns** - Write compelling, authentic messaging
- **Objection handling** - Develop effective responses
- **Qualification frameworks** - Implement BANT/NEPQ methodologies
- **Customer service** - Enhance support interactions
- **Copywriting** - Apply proven frameworks to any medium

## Core Philosophy

**Authentic persuasion** creates genuine connection, addresses real needs, and makes people feel valued—not sold to. Combine timeless psychology with modern frameworks for ethical, effective influence.

---

# Part 1: Foundation Principles (Dale Carnegie)

## The 6 Ways to Make People Like You

### 1. Become Genuinely Interested
**Application**: Ask about their specific situation, not yours
- ❌ "Let me tell you about our product"
- ✅ "What made you start looking into [solution]?"

### 2. Smile (Show Warmth)
**Application**: Use enthusiastic, positive language
- ❌ "Okay" when customer shares info
- ✅ "That's great! Tell me more about that"

### 3. Use Their Name
**Application**: Personalize naturally throughout conversation
- ❌ "Thanks for sharing"
- ✅ "Thanks for sharing that, Maria!"

### 4. Be a Good Listener
**Application**: 70% listening, 30% talking ratio
- ❌ Immediately pitching after hello
- ✅ "Tell me more about [their concern]"

### 5. Talk in Their Terms
**Application**: Frame around their goals, not your product
- ❌ "Our product does X, Y, Z"
- ✅ "This helps you achieve [their stated goal]"

### 6. Make Them Feel Important
**Application**: Validate their concerns and expertise
- ❌ Ignoring their questions
- ✅ "That's a smart question. Here's why..."

## The 12 Ways to Win People to Your Thinking

### 7. Avoid Arguments
- ❌ "Actually, you're wrong about that"
- ✅ "I understand why you'd think that. Many felt the same way before learning [X]"

### 8. Respect Their Opinions
- ❌ "That's not true"
- ✅ "I see your point. Here's another perspective..."

### 9. Admit Mistakes Quickly
- ❌ Making excuses
- ✅ "You're right, I should have mentioned that upfront"

### 10. Begin in a Friendly Way
- ❌ "I'm calling to sell you [X]"
- ✅ "Hi Maria! How's your day going?"

### 11. Get Them Saying "Yes"
**Application**: Start with easy agreements
- ✅ "You want to [obvious goal they stated], right?"
- ✅ "Sounds like budget is important to you?"

### 12. Let Them Talk More
**Application**: Ask questions, then actively listen
- Track ratio: Aim for 70% customer talking

### 13. Let Ideas Feel Like Theirs
- ❌ "You should buy this because..."
- ✅ "What would happen if you could [benefit they mentioned]?"

### 14. See Their Point of View
- ✅ "I understand budget is tight right now"
- ✅ "That timeline makes sense given [their situation]"

### 15. Be Sympathetic
**Application**: "I'd feel the same way" validation
- ✅ "I'd have the same questions if I were in your position"

### 16. Appeal to Nobler Motives
- ❌ "Make more money"
- ✅ "Help your team succeed"

### 17. Dramatize Your Ideas
**Application**: Paint pictures, tell stories
- ❌ "Our tool has analytics"
- ✅ "Imagine your team celebrating when they hit their goals 2 weeks early"

---

# Part 2: No-Go Sales Technique

## Core Concept
Remove all pressure by making it easy to say no. Paradoxically, this **increases** conversion rates.

## The 5 No-Go Principles

### 1. Permission-Based Engagement
Always ask before proceeding:
- ✅ "Is now a good time?"
- ✅ "Would it be okay if I showed you [X]?"
- ❌ Assuming availability

### 2. Easy Exit Strategy
Make declining comfortable:
- ✅ "If this isn't a fit, no problem at all"
- ✅ "Feel free to say no if this doesn't work for you"

### 3. Low-Commitment Next Steps
Break big asks into tiny steps:
- ❌ "Sign up today for $500/month"
- ✅ "Want to just take a quick look? No commitment"

### 4. Remove Time Pressure
Eliminate artificial urgency:
- ❌ "Limited time offer ends tonight!"
- ✅ "Take your time deciding. I'm here when you're ready"
- ⚠️ **Exception**: Genuine scarcity is okay if true

### 5. Honesty About Fit
Admit when something isn't right:
- ✅ "This might not be the best fit because [reason]"
- Builds trust for future opportunities

## No-Go Phrases

### ✅ Use These
- "No pressure at all"
- "Feel free to say no"
- "Is now a good time, or should I come back later?"
- "Would it be okay if...?"
- "I completely understand if this isn't right for you"
- "Take all the time you need"

### ❌ Avoid These
- "Limited time only"
- "This deal expires today"
- "You need to decide now"
- "This is your last chance"
- "Everyone else is doing it"

---

# Part 3: Copywriting Frameworks

## AIDA Framework
**Use for**: Email campaigns, landing pages, initial outreach

### A - Attention (Hook)
Grab attention with relevance:
- ✅ "Struggling with [specific pain they have]?"
- ✅ "What if you could [desired outcome] in [timeframe]?"

### I - Interest (Build curiosity)
Make them want to learn more:
- ✅ "Here's how [similar company] achieved [result]..."
- ✅ "The secret is [intriguing element]"

### D - Desire (Show benefit)
Make them want what you're offering:
- ✅ "Imagine [vivid picture of success]"
- ✅ "You'll be able to [specific benefit]"

### A - Action (Clear CTA)
Make the next step obvious and easy:
- ✅ "Click here to see how it works"
- ✅ "Want me to show you a quick example?"

## PAS Framework
**Use for**: Objection handling, problem-aware prospects

### P - Problem
Identify and agitate the pain:
- ✅ "You're probably tired of [specific frustration]"
- ✅ "Most people struggle with [pain point]"

### A - Agitate
Make the problem feel urgent:
- ✅ "Every day this continues, you're losing [specific cost]"
- ✅ "And it only gets worse when [complication]"

### S - Solution
Present your offer as the answer:
- ✅ "That's exactly why we created [solution]"
- ✅ "Here's how [solution] solves that..."

## BAB Framework (Before-After-Bridge)
**Use for**: Storytelling, case studies

### Before
Paint the pain state:
- ✅ "Sarah was spending 10 hours/week on [task]"

### After
Show the transformation:
- ✅ "Now she does it in 30 minutes and has time for [benefit]"

### Bridge
Show how they got there:
- ✅ "Here's exactly what changed when she started using [solution]"

## The 4 U's Formula (Headlines/Subject Lines)

1. **Useful** - Promise clear benefit
2. **Urgent** - Create time sensitivity (if genuine)
3. **Unique** - Stand out from competition
4. **Ultra-specific** - Use concrete numbers/details

Example:
- ❌ "Improve your sales" (vague, generic)
- ✅ "How 3 SDRs doubled their close rate in 14 days without cold calling"

---

# Part 4: Storytelling Framework

## The Story Spine (Pixar Method)

Use this structure for case studies, examples, testimonials:

1. **Once upon a time** - Set the scene
   - "Maria was running a small dental clinic"

2. **Every day** - Establish routine/problem
   - "Every day she struggled to fill appointment slots"

3. **But one day** - Inciting incident
   - "But one day she discovered [solution]"

4. **Because of that** - Consequence
   - "Because of that, she started getting more bookings"

5. **Because of that** - Escalation
   - "Because of that, she hired more staff"

6. **Until finally** - Climax
   - "Until finally she doubled her revenue"

7. **And ever since** - Resolution
   - "And ever since, she's been fully booked every week"

## The Hero's Journey (Simplified for Sales)

### 1. Ordinary World
"Before [solution], they were struggling with [problem]"

### 2. Call to Adventure
"Then they realized they needed to change"

### 3. Crossing the Threshold
"They decided to try [solution]"

### 4. Tests and Trials
"It wasn't easy at first, but..."

### 5. Reward
"Now they're achieving [specific result]"

### 6. Return with Elixir
"And here's what they learned that can help you..."

## Emotional Arcs

### The "Rags to Riches" Arc
- Start: Pain/struggle
- Journey: Incremental wins
- End: Success/transformation
- **Best for**: Underdog stories, overcoming obstacles

### The "Man in a Hole" Arc
- Start: Comfortable
- Middle: Crisis/problem
- End: Solution/recovery
- **Best for**: Problem-solution narratives

### The "Cinderella" Arc
- Multiple ups and downs before final success
- **Best for**: Complex B2B journeys

---

# Part 5: NEPQ (Neuro-Emotional Persuasion Questions)

## What is NEPQ?
Questions that bypass logical resistance and tap into emotional drivers. Created by Jeremy Miner for high-ticket sales.

## Core NEPQ Principles

### 1. Never Pitch - Always Ask
- ❌ "Our product has [feature]"
- ✅ "What would happen if you could [benefit]?"

### 2. Create Gap Between Current and Desired State
- ✅ "Where are you now vs where you want to be?"
- ✅ "What's the cost of staying where you are?"

### 3. Uncover Emotional Drivers
- ✅ "How does that make you feel?"
- ✅ "What would it mean to you if [desired outcome]?"

## NEPQ Question Types

### Situation Questions
Understand their current state:
- "Tell me about your current process for [X]"
- "How are you handling [problem] right now?"
- "Walk me through what a typical day looks like"

### Problem Awareness Questions
Make them acknowledge pain:
- "What's the biggest challenge you're facing with [X]?"
- "How long has this been an issue?"
- "What have you tried so far?"

### Implication Questions
Amplify the cost of inaction:
- "What happens if this continues for another 6 months?"
- "How is this affecting your [team/revenue/time]?"
- "What does this problem cost you per month?"

### Need-Payoff Questions
Make them sell themselves:
- "If you could [solve problem], how would that change things?"
- "What would it mean to your team if [benefit]?"
- "How would your day look different if [desired outcome]?"

### Emotional Connection Questions
Tap into deeper motivations:
- "How does that make you feel?"
- "Why is this important to you personally?"
- "What would success look like for you?"

### Commitment Questions
Test readiness to move forward:
- "If we could solve this, what would you need to see?"
- "What's holding you back from making a decision?"
- "On a scale of 1-10, how important is solving this?"

## NEPQ Conversation Flow

```
1. SITUATION: Understand where they are
   "What's your current situation with [X]?"

2. PROBLEM: Identify pain points
   "What challenges are you facing?"

3. IMPLICATIONS: Amplify cost
   "How is this affecting your [business/life]?"
   "What happens if nothing changes?"

4. NEED-PAYOFF: Paint the future
   "What would it mean if you could solve this?"
   "How would that change things for you?"

5. EMOTIONAL: Connect to feelings
   "How would that make you feel?"

6. COMMITMENT: Check readiness
   "If this could solve that, would you want to move forward?"
```

## NEPQ Do's and Don'ts

### ✅ Do
- Ask open-ended questions
- Let silence work for you (pause after questions)
- Mirror their language back to them
- Build on their answers with follow-ups
- Focus on their pain, not your product

### ❌ Don't
- Pitch features too early
- Ask yes/no questions
- Fill every silence
- Ignore emotional cues
- Jump to solution before understanding problem

---

# Part 6: BANT Qualification Framework

## What is BANT?
IBM's classic sales qualification framework - still highly effective for B2B.

### B - Budget
**Questions to ask**:
- "What budget have you allocated for solving this?"
- "What's the cost of not solving this problem?"
- "How are you currently spending money on this?"

**Red flags**:
- "We don't have budget" = Not a priority
- "I don't know" = Not decision maker
- "Whatever it costs" = May have unrealistic expectations

**Qualification**:
- ✅ Specific budget range mentioned
- ✅ Budget approved or approval process clear
- ⚠️ No budget but problem is costing them money = Build ROI case

### A - Authority
**Questions to ask**:
- "Who else is involved in this decision?"
- "What's your typical process for approving [solutions like this]?"
- "Will you be making this decision alone or with others?"

**Red flags**:
- "I need to check with my boss" = Go higher
- Vague about decision process = Multiple stakeholders

**Qualification**:
- ✅ You're talking to the decision maker
- ✅ You know the entire decision committee
- ✅ Clear decision process outlined

### N - Need
**Questions to ask**:
- "What's the business impact of this problem?"
- "What happens if you don't solve this?"
- "What have you tried before?"

**Red flags**:
- Can't articulate impact = Nice-to-have, not must-have
- No urgency = Will never close

**Qualification**:
- ✅ Clear, quantifiable pain
- ✅ Problem is costing them money/time/opportunity
- ✅ They've tried other solutions (market educated)

### T - Timeline
**Questions to ask**:
- "When do you need this implemented by?"
- "What's driving that timeline?"
- "What happens if you miss that deadline?"

**Red flags**:
- "No rush" = Low priority
- "ASAP" without reason = Might not be serious

**Qualification**:
- ✅ Specific date with business reason
- ✅ Consequences for missing timeline
- ✅ Internal deadlines align with your sales cycle

## BANT Scoring System

Create a simple scorecard:

```
Budget: 🟢 Confirmed | 🟡 Estimated | 🔴 None
Authority: 🟢 Decision Maker | 🟡 Influencer | 🔴 User Only
Need: 🟢 Urgent | 🟡 Important | 🔴 Nice-to-have
Timeline: 🟢 <30 days | 🟡 30-90 days | 🔴 >90 days

Qualification Threshold: Minimum 2 🟢 + 2 🟡
```

## Modern BANT Variations

### MEDDIC (For complex B2B)
- **M**etrics - Quantifiable business impact
- **E**conomic Buyer - Who controls budget
- **D**ecision Criteria - What they're evaluating
- **D**ecision Process - Steps to approval
- **I**dentify Pain - Business problem
- **C**hampion - Internal advocate

### CHAMP (Customer-first approach)
- **C**hallenges - What problems do they face?
- **A**uthority - Who makes decisions?
- **M**oney - What's the budget?
- **P**rioritization - How urgent is this?

### GPCT (Goal-focused)
- **G**oals - What are they trying to achieve?
- **P**lans - How are they trying to get there?
- **C**hallenges - What's preventing success?
- **T**imeline - When do they need it by?

---

# Part 7: Integrated Application

## The Complete High-Converting Conversation Flow

### Stage 1: Opening (Carnegie + No-Go)
```
1. Warm greeting with name (Carnegie #3, #10)
   "Hi Maria! Thanks for reaching out."

2. Permission-based engagement (No-Go #1)
   "Is now a good time to chat, or should I call back?"

3. Show genuine interest (Carnegie #1)
   "What brings you here today?"
```

### Stage 2: Discovery (NEPQ + BANT)
```
1. Situation questions (NEPQ)
   "Tell me about your current situation with [X]"

2. Problem awareness (NEPQ)
   "What's your biggest challenge right now?"

3. Budget qualification (BANT - subtle)
   "What's this problem costing you per month?"

4. Authority check (BANT)
   "Who else is involved in solving this?"

5. Need amplification (NEPQ + BANT)
   "How is this affecting your [business/team]?"

6. Timeline discovery (BANT)
   "When do you need this solved by?"
```

### Stage 3: Agitation (PAS + Storytelling)
```
1. Problem restatement
   "So if I'm hearing you right, you're struggling with [pain]"

2. Implications (NEPQ)
   "What happens if this continues for 6 more months?"

3. Emotional connection (NEPQ)
   "How does that make you feel?"

4. Story example (BAB framework)
   "I worked with someone in a similar situation..."
```

### Stage 4: Solution (AIDA + Carnegie)
```
1. Need-payoff question (NEPQ)
   "What would it mean if you could solve this?"

2. Let them paint the picture (Carnegie #13)
   "How would your day look different?"

3. Tie to their interests (Carnegie #5)
   "Based on what you said about [their goal]..."

4. Dramatize the benefit (Carnegie #17)
   "Imagine [vivid future state]"
```

### Stage 5: Low-Pressure Close (No-Go)
```
1. Easy next step
   "Want to see a quick example of how this works?"

2. Remove pressure
   "No commitment needed - just want to show you"

3. Permission-based
   "Would that be helpful, or is this not the right time?"

4. Respect their decision (Carnegie #8)
   "Either way is totally fine"
```

## Objection Handling Framework

### The Feel-Felt-Found Method
```
"I understand how you FEEL. Many of our clients FELT the same way.
What they FOUND was [benefit that addresses concern]."
```

### Examples by Objection Type

#### "It's too expensive"
```
Feel: "I understand budget is a concern"
Felt: "Many clients felt the same way initially"
Found: "What they found was that not solving this was costing
them 3x more per month than our solution"

+ NEPQ: "What's the cost of staying where you are?"
+ BANT: Check if budget concern is real or smokescreen
```

#### "I need to think about it"
```
Feel: "Of course - this is an important decision"
Felt: "Others wanted time to think too"
Found: "What they found helpful was understanding exactly
what they needed to think through"

+ NEPQ: "What specifically do you need to think about?"
+ BANT: Check authority - are they the decision maker?
```

#### "We're already using [competitor]"
```
Feel: "That's great you have something in place"
Felt: "Many of our clients were using [competitor] too"
Found: "What they found was [specific advantage]"

+ Carnegie #8: Never badmouth competitor
+ NEPQ: "What's working well? What's not?"
```

#### "Not the right time"
```
Feel: "I completely understand timing is important"
Felt: "Timing was a concern for others too"
Found: "What they found was that waiting cost them [X]"

+ NEPQ: "What happens if you wait?"
+ BANT: Timeline qualification - is there urgency?
+ No-Go: "No pressure - when would be better?"
```

---

# Part 8: Copywriting Best Practices

## Power Words

### Emotion Triggers
**Trust**: Proven, certified, guaranteed, tested, authentic, official
**Urgency**: Now, today, limited, deadline, last chance, ending
**Exclusivity**: Secret, exclusive, insider, members-only, private
**Curiosity**: Discover, reveal, secret, hidden, unveil, surprising
**Value**: Free, bonus, save, discount, extra, complimentary

### Action Words
Grab, boost, skyrocket, transform, unleash, master, accelerate, unlock

### Sensory Words
Crystal-clear, razor-sharp, smooth, effortless, streamlined, seamless

## Writing Principles

### 1. Clarity Over Cleverness
- ❌ "Synergistic paradigm shift in customer acquisition"
- ✅ "Get more customers"

### 2. Specific Over Generic
- ❌ "Increase your sales"
- ✅ "Add $50K in revenue in 90 days"

### 3. Benefits Over Features
- ❌ "AI-powered analytics dashboard"
- ✅ "See exactly which campaigns drive revenue"

### 4. Show Don't Tell
- ❌ "Our software is fast"
- ✅ "Load reports in 0.3 seconds"

### 5. One Big Idea Per Message
- Focus on single most compelling benefit
- Don't overwhelm with everything at once

## Readability Optimization

### Sentence Structure
- Vary length: mix short and medium sentences
- Average 15-20 words per sentence
- Use active voice: "We help you" not "You are helped by us"

### Paragraph Structure
- 2-3 sentences max per paragraph
- White space = easier reading
- Use bullet points for lists

### Formatting for Skimmers
- **Bold** key points
- Use subheadings every 2-3 paragraphs
- Callout boxes for important info
- Bullet points > long paragraphs

---

# Part 9: A/B Testing Framework

## Elements to Test

### Headlines/Subject Lines
Test variations of:
- Length (short vs long)
- Angle (benefit vs curiosity vs urgency)
- Personalization (with name vs without)
- Question vs statement

### Opening Lines
Test:
- Direct vs friendly
- Question vs statement
- Personal vs professional tone

### Call-to-Action
Test:
- Button text ("Get Started" vs "Show Me How")
- CTA placement (top vs bottom vs both)
- Urgency level (high vs low)

### Value Proposition
Test:
- Feature-focused vs benefit-focused
- Emotional vs logical appeal
- Different primary benefits

### Social Proof
Test:
- Numbers vs testimonials
- Industry-specific vs general
- Before-after stories vs results only

## Testing Methodology

### Minimum Sample Size
- At least 100 conversions per variation
- Or 1,000+ total interactions minimum
- Statistical significance: 95% confidence level

### What to Measure
**Primary metrics**:
- Conversion rate
- Response rate
- Engagement rate

**Secondary metrics**:
- Time to conversion
- Message length (theirs)
- Objection frequency

### When to Stop Test
- Statistical significance reached
- Clear winner emerges (>20% improvement)
- After predetermined time period
- After predetermined sample size

---

# Part 10: Common Mistakes to Avoid

## ❌ Top 10 Conversion Killers

### 1. Talking Too Much
**Problem**: Dominating with features
**Solution**: 70/30 listen/talk ratio

### 2. Arguing with Objections
**Problem**: "Actually, you're wrong..."
**Solution**: "I understand why you'd think that..."

### 3. Fake Urgency
**Problem**: False scarcity/deadlines
**Solution**: Only mention real constraints

### 4. Generic Messaging
**Problem**: One-size-fits-all pitch
**Solution**: Customize to their situation

### 5. Being Pushy
**Problem**: High-pressure tactics
**Solution**: No-Go approach

### 6. Not Using Names
**Problem**: Impersonal communication
**Solution**: Natural name usage

### 7. Leading with Features
**Problem**: "We have X, Y, Z"
**Solution**: "You want [goal], right?"

### 8. Ignoring Emotional Drivers
**Problem**: Pure logic
**Solution**: NEPQ emotional questions

### 9. Skipping Qualification
**Problem**: Talking to non-buyers
**Solution**: BANT framework

### 10. Giving Up Too Early
**Problem**: One "no" = done
**Solution**: Multiple touchpoints

---

# Part 11: Quick Reference Checklists

## Pre-Conversation Checklist
- [ ] Do I know their name?
- [ ] Do I know what problem they're trying to solve?
- [ ] Am I prepared to listen more than talk?
- [ ] Am I ready to make it easy to say no?
- [ ] Do I have relevant stories/examples ready?

## During Conversation Checklist
- [ ] Used their name (Carnegie #3)
- [ ] Asked permission before proceeding (No-Go #1)
- [ ] Asked open questions (NEPQ)
- [ ] Listened actively (Carnegie #12)
- [ ] Qualified BANT
- [ ] Showed empathy (Carnegie #15)
- [ ] Removed pressure (No-Go)
- [ ] Provided value first

## Post-Conversation Checklist
- [ ] Did I make them feel important? (Carnegie #6)
- [ ] Did I respect their time? (Carnegie #8)
- [ ] Did I provide value regardless of outcome?
- [ ] Did I qualify properly? (BANT complete)
- [ ] Would I want to interact with me?

## Script Optimization Checklist
- [ ] Carnegie principles applied
- [ ] No-Go elements included
- [ ] Copywriting framework used (AIDA/PAS/BAB)
- [ ] NEPQ questions integrated
- [ ] BANT qualification built in
- [ ] Storytelling elements present
- [ ] Objection responses prepared
- [ ] Clear, easy CTA

---

# Part 12: Resources

## References Directory

See `references/` for detailed frameworks:
- **carnegie-principles.md** - Full Carnegie methodology with examples
- **nepq-questions.md** - Complete NEPQ question bank
- **copywriting-formulas.md** - Additional frameworks (QUEST, FAB, etc.)
- **storytelling-templates.md** - Story structures for different scenarios

## Key Principles Summary

### Carnegie Foundation
- Make people like you (be interested, use name, listen)
- Win them to your thinking (avoid arguments, respect opinions)
- Dramatize ideas and appeal to emotions

### No-Go Technique
- Permission-based engagement
- Easy exit strategy
- Remove all pressure

### NEPQ Method
- Ask, don't pitch
- Uncover emotional drivers
- Create gap between current and desired state

### BANT Qualification
- Budget - Can they afford it?
- Authority - Can they decide?
- Need - Is it urgent?
- Timeline - When do they need it?

### Copywriting Frameworks
- **AIDA** - Attention, Interest, Desire, Action
- **PAS** - Problem, Agitate, Solution
- **BAB** - Before, After, Bridge

---

## Remember

> "You can make more friends in two months by becoming interested in other people
> than you can in two years by trying to get other people interested in you."
> — Dale Carnegie

The best sales conversations don't feel like sales. They feel like helpful conversations with someone who genuinely cares about solving your problem.

**Use this skill to**: Audit existing scripts, optimize chatbot prompts, train sales teams, handle objections, qualify prospects, and create authentic, high-converting conversations.

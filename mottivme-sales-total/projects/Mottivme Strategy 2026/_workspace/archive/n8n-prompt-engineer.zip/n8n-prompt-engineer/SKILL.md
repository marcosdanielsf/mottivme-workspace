---
name: n8n-prompt-engineer
description: Expert n8n AI agent prompt engineer using the CRITICS framework (Constraints, Role, Inputs, Tools, Instructions, Conclusions, Solutions). Combines structured prompt engineering with conversational influence techniques for customer-facing agents. Supports prompt creation, audit, and optimization for n8n workflows with n8n-specific syntax and patterns.
---

# n8n AI Agent Prompt Engineer

Master prompt engineering for n8n AI agents using the battle-tested CRITICS framework, enhanced with conversational influence techniques for customer-facing scenarios.

## 🎯 When to Use This Skill

Use this skill when you need to:
- ✅ Create new AI agent prompts for n8n workflows
- ✅ Audit existing n8n agent prompts for quality and effectiveness
- ✅ Optimize prompts for better performance and token efficiency
- ✅ Convert unstructured requirements into CRITICS-formatted prompts
- ✅ Add conversational influence to customer-facing agents (SDR, support, sales)
- ✅ Validate n8n-specific syntax and tool integrations
- ✅ Create prompts for specific agent types (B2C, B2E, data processing, API integration)

## 📋 The CRITICS Framework

CRITICS is a structured approach to prompt engineering that ensures completeness and clarity:

```
C - Constraints (Restrições)
R - Role (Papel)
I - Inputs (Entradas)
T - Tools (Ferramentas)
I - Instructions (Instruções)
C - Conclusions (Saídas Esperadas)
S - Solutions (Tratamento de Erros)
```

### Why CRITICS Works

- **Structured**: Forces systematic thinking about all prompt aspects
- **Complete**: Prevents missing critical information
- **Maintainable**: Easy to update specific sections
- **n8n-Native**: Designed for tool-calling AI agents in workflows
- **Error-Resilient**: Built-in error handling patterns

## 🏗️ CRITICS Framework Deep Dive

### 1️⃣ Constraints (Restrições)

**Purpose**: Define boundaries, rules, and limitations the agent MUST follow.

**What to Include**:
- Mandatory behaviors (NUNCA, SEMPRE, OBRIGATÓRIO)
- Formatting requirements (XML, JSON, Markdown)
- Security/safety rules (data protection, PII handling)
- Token/context limits
- Temporal awareness: `A data de hoje é {{ $now }}`
- Output format restrictions

**Best Practices**:
```markdown
<Constraints>
* A data de hoje é {{ $now }}. Sempre use esta data para referências temporais
* NUNCA [comportamento proibido]
* SEMPRE [comportamento obrigatório]
* Use tags XML para estruturar respostas quando solicitado
* Máximo de 3 perguntas de esclarecimento
* CRÍTICO: [regra de negócio crítica]
</Constraints>
```

**Common Mistakes**:
- ❌ Making constraints too vague ("seja profissional")
- ❌ Forgetting to include {{ $now }} for time-aware agents
- ❌ Not marking critical business rules as "CRÍTICO" or "⚠️"
- ❌ Mixing instructions with constraints (constraints = rules, instructions = process)

### 2️⃣ Role (Papel)

**Purpose**: Define WHO the agent is and its core identity.

**What to Include**:
- Primary function/expertise
- Personality traits (when relevant for customer-facing)
- Scope of authority
- Brand voice guidelines

**Best Practices**:
```markdown
<Role>
Você é [título/função] especialista em [domínio].
Seu propósito é [objetivo primário].
[Traços de personalidade para customer-facing: amigável, empático, consultivo]
</Role>
```

**Examples**:
- **B2C SDR**: "Você é Julia, uma SDR (Sales Development Representative) especialista em ortodontia. Seu propósito é qualificar leads e agendar avaliações gratuitas. Você é amigável, usa linguagem informal (você/vc), e aplica técnicas consultivas de vendas."
- **B2E Assistant**: "Você é Maria, assistente interna especializada em gestão de agenda e reagendamentos. Seu propósito é otimizar a ocupação de horários e reduzir no-shows. Você é eficiente, empática e proativa."
- **Data Processor**: "Você é um agente de processamento de dados especializado em normalização e enriquecimento de leads. Seu propósito é padronizar formatos, validar informações e enriquecer registros com dados externos."

### 3️⃣ Inputs (Entradas)

**Purpose**: Define what data the agent receives and in what format.

**What to Include**:
- Required input parameters
- Optional input parameters
- Expected data types and formats
- n8n dynamic variables: `{{ $json.field }}`, `{{ $('NodeName').item.json.field }}`
- Context from previous nodes

**Best Practices**:
```markdown
<Inputs>
* {{ $json.query }} - Consulta do usuário (obrigatório)
* {{ $json.user_context }} - Contexto adicional (opcional)
* {{ $('PreviousNode').item.json.lead_data }} - Dados do lead
* {{ $now }} - Data/hora atual
* {{ $execution.id }} - ID da execução (para logging)
</Inputs>
```

**n8n Variable Patterns**:
- Current item: `{{ $json.field }}`
- Previous node: `{{ $('NodeName').item.json.field }}`
- All items: `{{ $items('NodeName') }}`
- Current date: `{{ $now.toLocaleString() }}`
- Workflow ID: `{{ $workflow.id }}`
- Execution ID: `{{ $execution.id }}`

### 4️⃣ Tools (Ferramentas)

**Purpose**: Document available tools and their parameters.

**What to Include**:
- Tool name and purpose
- Required parameters
- Optional parameters with defaults
- Expected outputs
- Usage examples

**Format**:
```markdown
<Tools>
1. ToolName - Descrição clara do que a ferramenta faz
   * parameterName (obrigatório) - Descrição do parâmetro
   * optionalParam (opcional, default: valor) - Descrição

   Exemplo de uso:
   {
     "tool": "ToolName",
     "parameters": {
       "parameterName": "valor"
     }
   }

2. WebSearch_Tool - Busca na web usando Perplexity
   * searchTerm (obrigatório) - Consulta de busca

3. DatabaseQuery_Tool - Consulta banco de dados
   * query (obrigatório) - SQL query
   * timeout (opcional, default: 30s) - Timeout em segundos
</Tools>
```

**When No Tools Needed**:
```markdown
<Tools>
Este agente não requer ferramentas externas. Trabalha apenas com processamento de linguagem natural.
</Tools>
```

### 5️⃣ Instructions (Instruções)

**Purpose**: Step-by-step process the agent should follow.

**What to Include**:
- Numbered/bulleted workflow steps
- Decision trees (se X, então Y)
- Edge case handling
- Integration points with other nodes
- Validation steps

**Best Practices**:
```markdown
<Instructions>
Fluxo Principal:
  1. Analise a entrada {{ $json.query }}
  2. Extraia informações chave [listar quais]
  3. Se [condição], então:
     a. [ação 1]
     b. [ação 2]
  4. Caso contrário:
     a. [ação alternativa]
  5. Valide o resultado contra [critérios]
  6. Retorne no formato especificado em Conclusions

Para Tarefas Específicas:

Tarefa A (ex: Qualificação de Lead):
  1. Faça pergunta de descoberta
  2. Escute a resposta
  3. Classifique usando BANT (Budget, Authority, Need, Timeline)
  4. Se qualificado, ofereça próximo passo
  5. Se não qualificado, agradeça e finalize

Tarefa B (ex: Reagendamento):
  1. Confirme necessidade de reagendamento
  2. Apresente 2-3 opções de horários
  3. Use Feel-Felt-Found para objeções
  4. Confirme novo horário
  5. Envie confirmação

Tratamento de Ambiguidade:
  * Se entrada não clara, faça até 3 perguntas de esclarecimento
  * Não presuma informações críticas
  * Sempre valide antes de executar ações irreversíveis
</Instructions>
```

**For Customer-Facing Agents**:
Include conversational flow patterns:
```markdown
Padrão de Conversa Consultiva:
  1. Rapport: Use nome, mostre interesse genuíno
  2. Descoberta: Perguntas NEPQ (Situação → Problema → Implicação → Need-Payoff)
  3. Apresentação: Foque em benefícios, não features
  4. Objeções: Use Feel-Felt-Found
  5. Fechamento: Assumptive close ou choice close
```

### 6️⃣ Conclusions (Saídas Esperadas)

**Purpose**: Define exactly what the agent should output.

**What to Include**:
- Output format (JSON, Markdown, plain text)
- Required fields
- Optional fields
- Validation criteria
- Examples of good outputs

**Best Practices**:
```markdown
<Conclusions>
Formato de Saída: [JSON | Markdown | Texto Puro]

Campos Obrigatórios:
* campo1 - Descrição e tipo
* campo2 - Descrição e tipo

Campos Opcionais:
* campoX - Quando incluir

Exemplo de Saída Válida:
```json
{
  "status": "qualified",
  "lead_score": 85,
  "next_action": "schedule_call",
  "notes": "Cliente interessado em solução enterprise"
}
```

Validação:
* Todos os campos obrigatórios devem estar presentes
* lead_score deve estar entre 0-100
* next_action deve ser um dos valores pré-definidos
* Não inclua informações de suporte ou explicações - apenas o output estruturado
</Conclusions>
```

### 7️⃣ Solutions (Tratamento de Erros)

**Purpose**: Handle edge cases, errors, and unexpected situations.

**What to Include**:
- Common error scenarios
- Recovery strategies
- Fallback behaviors
- Escalation paths
- Logging requirements

**Best Practices**:
```markdown
<Solutions>
Cenário 1: Entrada Inválida
* Se {{ $json.query }} estiver vazio ou null
* Ação: Retorne erro estruturado com código 400
* Log: {{ $execution.id }} - INPUT_VALIDATION_FAILED

Cenário 2: Tool Timeout
* Se ferramenta não responder em 30s
* Ação: Use dados em cache se disponível, senão retorne erro 503
* Log: {{ $execution.id }} - TOOL_TIMEOUT - {{ $now }}

Cenário 3: Informação Ambígua
* Se não conseguir classificar com confiança >70%
* Ação: Faça até 3 perguntas de esclarecimento
* Se ainda ambíguo, escale para humano

Cenário 4: Cliente Insatisfeito (Customer-Facing)
* Se detectar sentimento negativo ou palavras-chave de frustração
* Ação: Mude para modo empático, ofereça transferência para supervisor
* Nunca argumente ou defensivo

Cenário 5: Dados Faltando
* Se campo obrigatório estiver ausente
* Ação: Solicite especificamente o campo faltando
* Não prossiga sem informação crítica

Logging Padrão:
* Sempre inclua {{ $execution.id }} nos logs
* Use níveis: INFO, WARNING, ERROR, CRITICAL
* Formato: [NÍVEL] {{ $now }} - {{ $execution.id }} - Mensagem
</Solutions>
```

## 🎨 Agent Type Templates

### Template 1: B2C SDR (Sales Development Representative)

```markdown
<Role>
Você é [Nome], SDR especialista em [área/produto].
Seu propósito é qualificar leads e agendar [consultas/demos].
Você é [amigável/consultivo/empático], usa linguagem [formal/informal].
</Role>

<Constraints>
* A data de hoje é {{ $now }}
* Use "você/vc" (informal) ou "Senhor(a)" (formal)
* NUNCA seja insistente ou pressione o lead
* SEMPRE aplique No-Go: permissão, easy exit, low commitment
* Máximo 3 mensagens sem resposta antes de pausar contato
* CRÍTICO: [regras de precificação, disponibilidade, compliance]
</Constraints>

<Inputs>
* {{ $json.lead_name }} - Nome do lead
* {{ $json.lead_phone }} - Telefone
* {{ $json.lead_source }} - Origem (Facebook, Google, Indicação)
* {{ $json.conversation_history }} - Histórico (opcional)
* {{ $('LeadScoring').item.json.score }} - Score de qualificação
</Inputs>

<Tools>
1. CheckAvailability - Verifica horários disponíveis
   * date (obrigatório) - Data desejada YYYY-MM-DD
   * duration (opcional, default: 30) - Duração em minutos

2. CreateAppointment - Cria agendamento
   * lead_id (obrigatório)
   * datetime (obrigatório)
   * type (obrigatório) - "evaluation" | "demo" | "consultation"
</Tools>

<Instructions>
Fluxo de Qualificação e Agendamento:

1. Saudação e Rapport:
   * Use o nome do lead
   * Mencione origem do contato
   * Mostre interesse genuíno (Carnegie #1)

2. Descoberta (NEPQ):
   * Situação: "Como você está [gerenciando X] hoje?"
   * Problema: "O que te motivou a buscar uma solução?"
   * Implicação: "Como isso está impactando [Y]?"
   * Need-Payoff: "O que mudaria se você resolvesse isso?"

3. Qualificação (BANT):
   * Budget: "Qual faixa de investimento faz sentido?"
   * Authority: "Você é a pessoa que decide sobre isso?"
   * Need: (já descoberto no passo 2)
   * Timeline: "Quando você gostaria de começar?"

4. Venda do Agendamento:
   * Use gatilho de escassez (se genuíno): "Tenho poucas vagas abertas"
   * Reforce valor: "Inclui [benefício 1], [benefício 2], [benefício 3]"
   * Ofereça 1 dia, 2 horários apenas
   * Assumptive close: "Prefere manhã ou tarde?"

5. Confirmação:
   * Repita data/hora
   * Envie confirmação
   * Defina expectativa: "Vai receber lembrete 24h antes"

Objeções Comuns:
* "Quanto custa?": [resposta específica do negócio]
* "Preciso pensar": Feel-Felt-Found
* "Não tenho tempo agora": Ofereça reagendar, baixa pressão
</Instructions>

<Conclusions>
Formato: Texto conversacional + JSON estruturado

Output Conversacional:
* Mensagem para o lead em linguagem natural
* Tom: [amigável/consultivo/profissional]
* Máximo [150-200] palavras por mensagem

Output Estruturado:
```json
{
  "action": "message_sent" | "appointment_created" | "lead_disqualified",
  "lead_score": 0-100,
  "bant_qualified": true/false,
  "next_follow_up": "2025-11-27T10:00:00Z",
  "notes": "Observações para time"
}
```
</Conclusions>

<Solutions>
* Se lead não responde 3x: Pause contato, marque para reativação em 30 dias
* Se lead pede desconto: Não tem autoridade, escale para supervisor
* Se detectar sentimento negativo: Modo empático, ofereça transferência
* Se horário indisponível: Use CheckAvailability, ofereça alternativas
* Se dados incompletos: Solicite especificamente o que falta
</Solutions>
```

### Template 2: B2E Internal Assistant

```markdown
<Role>
Você é [Nome], assistente interna especializada em [função].
Seu propósito é [objetivo interno: otimizar agenda, reduzir no-shows, etc].
Você é eficiente, empática e proativa.
</Role>

<Constraints>
* A data de hoje é {{ $now }}
* Prioridade: [P1: Urgente | P2: Alta | P3: Normal | P4: Baixa]
* SEMPRE envie notificações em horário comercial (9h-18h)
* NUNCA processe cancelamentos sem confirmação dupla
* Use tom profissional mas humanizado com pacientes/clientes
* Tom interno (com equipe) pode ser mais direto
</Constraints>

<Inputs>
* {{ $json.task_type }} - "reschedule" | "reminder" | "follow_up" | "optimization"
* {{ $json.appointment_id }} - ID do agendamento
* {{ $json.patient_data }} - Dados do paciente (nome, telefone, histórico)
* {{ $('Calendar').item.json.availability }} - Disponibilidade atual
</Inputs>

<Tools>
1. GetAppointment - Busca dados do agendamento
   * appointment_id (obrigatório)

2. UpdateAppointment - Atualiza agendamento
   * appointment_id (obrigatório)
   * new_datetime (obrigatório)
   * reason (obrigatório)

3. SendNotification - Envia notificação
   * recipient (obrigatório) - phone ou email
   * message (obrigatório)
   * channel (obrigatório) - "sms" | "whatsapp" | "email"
   * scheduled_time (opcional) - agendar envio
</Tools>

<Instructions>
Tarefa: Reagendamento Proativo

1. Identifique Necessidade:
   * Conflito de horário
   * Otimização de agenda (preencher gaps)
   * Proximidade de horário vago

2. Prepare Comunicação Humanizada:
   * Use nome do paciente
   * Explique motivo brevemente
   * Ofereça 2-3 alternativas próximas
   * Facilite resposta (responda 1, 2 ou 3)

3. Envie Notificação:
   * Canal preferencial do paciente
   * Horário apropriado (9h-18h)
   * Tom empático mas eficiente

4. Processe Resposta:
   * Confirme novo horário imediatamente
   * Agradeça compreensão
   * Atualize sistema
   * Notifique equipe se relevante

5. Follow-up:
   * Se sem resposta em 2h, reenvie (até 2x)
   * Se sem resposta após 2 tentativas, escale para equipe

Exemplo de Mensagem Humanizada:
"Oi [Nome]! Tudo bem? 😊

Precisei ajustar sua consulta de [data/hora original] por [motivo breve].

Consegui esses horários próximos pra você:
1) [Opção 1]
2) [Opção 2]
3) [Opção 3]

Qual funciona melhor? Só responder o número!"
</Instructions>

<Conclusions>
Output Interno (JSON):
```json
{
  "task_status": "completed" | "pending" | "escalated",
  "actions_taken": [
    "notification_sent",
    "appointment_updated"
  ],
  "new_appointment_datetime": "2025-11-27T14:00:00Z",
  "patient_response": "Opção 2",
  "notes": "Reagendado sem objeções"
}
```

Output Externo (Mensagem para Paciente):
* Tom: Amigável, empático, eficiente
* Máximo 100 palavras
* Facilite resposta (múltipla escolha ou sim/não)
</Conclusions>

<Solutions>
* Se paciente recusa todas opções: Ofereça ligação para buscar horário ideal
* Se sistema indisponível: Use dados em cache, sincronize depois
* Se conflito persiste: Escale para supervisor com contexto completo
* Se paciente responde fora horário: Queue mensagem para manhã seguinte
* Se erro no envio: Tente canal alternativo (WhatsApp → SMS → Email)
</Solutions>
```

### Template 3: Data Processor Agent

```markdown
<Role>
Você é um agente de processamento de dados especializado em [tipo de dados].
Seu propósito é normalizar, validar, enriquecer e transformar dados.
Você é preciso, consistente e orientado a qualidade.
</Role>

<Constraints>
* A data de hoje é {{ $now }}
* NUNCA modifique dados originais sem criar backup
* SEMPRE valide dados antes e depois do processamento
* Use padrões ISO para datas (YYYY-MM-DD) e timestamps (ISO 8601)
* Telefones: formato E.164 (+5511999999999)
* CRÍTICO: Dados sensíveis (CPF, email, telefone) devem ser criptografados em logs
* Máximo 1000 registros por batch (performance)
</Constraints>

<Inputs>
* {{ $json.records }} - Array de registros a processar
* {{ $json.operation }} - "normalize" | "validate" | "enrich" | "deduplicate"
* {{ $json.schema }} - Schema de validação (JSON Schema)
* {{ $('PreviousNode').item.json.enrichment_sources }} - Fontes de enriquecimento
</Inputs>

<Tools>
1. ValidateSchema - Valida contra JSON Schema
   * record (obrigatório) - Registro a validar
   * schema (obrigatório) - JSON Schema

2. EnrichData - Enriquece com dados externos
   * record (obrigatório)
   * sources (obrigatório) - ["clearbit", "hunter", "linkedin"]
   * fields (obrigatório) - Campos a enriquecer

3. DeduplicateRecords - Remove duplicatas
   * records (obrigatório)
   * match_fields (obrigatório) - ["email", "phone", "cpf"]
   * strategy (opcional, default: "keep_newest") - "keep_newest" | "keep_oldest" | "merge"
</Tools>

<Instructions>
Fluxo de Processamento:

1. Validação Inicial:
   * Valide cada registro contra schema
   * Identifique registros inválidos
   * Separe válidos e inválidos

2. Normalização:
   * Padronize formatos:
     - Telefones: remova caracteres, aplique E.164
     - Emails: lowercase, trim
     - Nomes: Title Case, remova espaços extras
     - Datas: converta para ISO 8601
   * Normalize campos de escolha (enum)

3. Enriquecimento (se solicitado):
   * Para cada registro válido
   * Busque dados em fontes externas
   * Merge com dados existentes
   * Valide novamente

4. Deduplicação (se solicitado):
   * Identifique duplicatas por match_fields
   * Aplique strategy definida
   * Log registros mesclados/removidos

5. Validação Final:
   * Revalide todos os registros
   * Calcule métricas de qualidade
   * Gere relatório

Métricas de Qualidade:
* Completude: % campos preenchidos
* Validade: % registros válidos
* Unicidade: % registros únicos
* Precisão: % dados enriquecidos corretamente
</Instructions>

<Conclusions>
Output Format: JSON estruturado

```json
{
  "summary": {
    "total_records": 1000,
    "valid_records": 950,
    "invalid_records": 50,
    "duplicates_removed": 15,
    "records_enriched": 900,
    "processing_time_ms": 5420
  },
  "quality_metrics": {
    "completeness": 92.5,
    "validity": 95.0,
    "uniqueness": 98.5,
    "enrichment_success_rate": 90.0
  },
  "processed_records": [
    {
      "id": "rec_001",
      "original": { "name": "joão silva", "phone": "(11) 99999-9999" },
      "processed": { "name": "João Silva", "phone": "+5511999999999" },
      "enriched_fields": ["company", "title", "linkedin_url"],
      "quality_score": 95
    }
  ],
  "invalid_records": [
    {
      "id": "rec_042",
      "errors": ["invalid_email", "missing_required_field:phone"],
      "original": { "name": "Maria", "email": "not-an-email" }
    }
  ],
  "execution_id": "{{ $execution.id }}",
  "timestamp": "{{ $now.toISOString() }}"
}
```
</Conclusions>

<Solutions>
* Se registro inválido: Não processe, adicione a invalid_records com erros detalhados
* Se API de enriquecimento falha: Continue sem enriquecer, marque como enrichment_failed
* Se timeout em lote grande: Divida em batches menores (500 registros)
* Se duplicata ambígua (scores iguais): Use strategy "keep_newest" por padrão
* Se schema inválido: Retorne erro 400 antes de processar qualquer registro
* Se dados sensíveis em logs: Mascare automaticamente (CPF → ***.***.***-**, email → m***@***)
</Solutions>
```

## 🎯 Conversational Influence Integration

For customer-facing agents (B2C SDR, Support, Sales), integrate these frameworks:

### Dale Carnegie Principles (Essentials)

**Making People Like You**:
1. **Use Their Name**: "Oi [Nome]!" (repeat 2-3x in conversation)
2. **Show Genuine Interest**: Ask about their specific situation
3. **Smile** (in text): Use emoji moderadamente (😊, ✨) quando apropriado ao tom
4. **Listen First**: Acknowledge their concerns before presenting solutions

**Winning Them to Your Thinking**:
5. **Respect Their Opinion**: "Entendo seu ponto" antes de apresentar alternativa
6. **Let Them Talk**: Ask open-ended questions
7. **Make Them Feel Important**: "Sua opinião é muito importante pra gente"

### No-Go Sales Technique

Paradoxically remove pressure to increase conversion:

1. **Permission-Based**: "Posso te fazer algumas perguntas?" / "Tudo bem se eu explicar como funciona?"
2. **Easy Exit**: "Se não fizer sentido, sem problema!" / "A qualquer momento você pode desistir"
3. **Low Commitment**: Start with small asks (scheduling, not buying)
4. **No Time Pressure**: "Não precisa decidir agora"
5. **Honesty About Fit**: "Vou ser sincero, talvez não seja ideal pra você se..."

### NEPQ (Neuro-Emotional Persuasion Questions)

Progressive questioning to uncover emotional drivers:

1. **Situation**: "Como você está [gerenciando X] hoje?"
2. **Problem Awareness**: "O que te motivou a buscar uma solução?"
3. **Implications**: "Como isso está impactando [área importante]?"
4. **Need-Payoff**: "O que mudaria pra você se resolvesse isso?"
5. **Emotional Connection**: "Como você se sentiria se conseguisse [resultado]?"
6. **Commitment**: "Se eu mostrar como funciona, você está aberto a testar?"

### Feel-Felt-Found (Objection Handling)

3-step empathy pattern:

```
Cliente: "Não sei se tenho dinheiro pra isso agora"

Agente:
1. Feel: "Eu entendo como você se sente, o investimento é uma decisão importante"
2. Felt: "Muitos dos nossos clientes sentiram a mesma coisa no início"
3. Found: "Mas o que eles descobriram é que, dividindo em [parcelas], fica R$ [valor/dia] por dia - menos que um café"
```

### Copywriting Frameworks

**AIDA (Attention, Interest, Desire, Action)**:
```
A - "Olá [Nome]! Vi que você se interessou por [produto]"
I - "Imagino que você esteja buscando [resolver problema X]"
D - "Com nosso [produto], você consegue [benefício] + [benefício] + [benefício]"
A - "Que tal marcarmos 15min pra eu te mostrar como funciona?"
```

**PAS (Problem, Agitate, Solution)**:
```
P - "Sei que [problema] pode ser frustrante"
A - "E isso provavelmente está [impacto negativo], o que acaba [consequência]"
S - "A boa notícia é que com [solução], você resolve [benefício específico]"
```

## 📊 Prompt Audit Checklist

Use this checklist when auditing existing n8n agent prompts:

### ✅ Structure (CRITICS Framework)
- [ ] All 7 CRITICS sections present (C-R-I-T-I-C-S)
- [ ] Sections in correct order
- [ ] XML tags used consistently
- [ ] Clear separation between sections

### ✅ Constraints Section
- [ ] Includes `{{ $now }}` for time awareness
- [ ] Critical business rules marked as "CRÍTICO" or "⚠️"
- [ ] NUNCA/SEMPRE rules clearly stated
- [ ] Output format specified
- [ ] Token/context limits defined (if applicable)

### ✅ Role Section
- [ ] Clear agent identity and purpose
- [ ] Appropriate personality traits (for customer-facing)
- [ ] Scope of authority defined
- [ ] Brand voice aligned (if customer-facing)

### ✅ Inputs Section
- [ ] All n8n variables documented
- [ ] Variable syntax correct: `{{ $json.field }}`
- [ ] Required vs optional inputs marked
- [ ] Data types specified

### ✅ Tools Section
- [ ] All available tools documented
- [ ] Parameters clearly explained (required/optional)
- [ ] Examples provided
- [ ] If no tools: explicitly stated

### ✅ Instructions Section
- [ ] Step-by-step workflow defined
- [ ] Decision trees for branching logic
- [ ] Edge cases handled
- [ ] Integration points documented
- [ ] For customer-facing: conversational flow included

### ✅ Conclusions Section
- [ ] Output format clearly specified (JSON/Markdown/Text)
- [ ] Required fields documented
- [ ] Validation criteria defined
- [ ] Example outputs provided
- [ ] Specifies "no extra information" if applicable

### ✅ Solutions Section
- [ ] Common error scenarios covered
- [ ] Recovery strategies defined
- [ ] Escalation paths documented
- [ ] Logging requirements specified
- [ ] Fallback behaviors defined

### ✅ Customer-Facing Enhancements (if applicable)
- [ ] Dale Carnegie principles integrated
- [ ] No-Go Sales technique applied (low pressure)
- [ ] NEPQ questions included for discovery
- [ ] Feel-Felt-Found for objections
- [ ] BANT qualification (for B2C sales)
- [ ] Scarcity/urgency is GENUINE (not artificial)
- [ ] Tone is appropriate (amigável/consultivo/empático)

### ✅ n8n-Specific
- [ ] Variable syntax correct
- [ ] Node references valid
- [ ] Execution ID used in logging: `{{ $execution.id }}`
- [ ] Date formatting appropriate: `{{ $now.toISOString() }}`
- [ ] Tool parameter types match n8n expectations

### ✅ Quality Checks
- [ ] No spelling/grammar errors (Portuguese)
- [ ] Consistent terminology throughout
- [ ] Examples are realistic and helpful
- [ ] No contradictory instructions
- [ ] Appropriate length (not bloated)

## 🔧 n8n-Specific Syntax Reference

### Dynamic Variables

```javascript
// Current item data
{{ $json.fieldName }}
{{ $json['field-with-dashes'] }}
{{ $json.nested.field }}

// Previous node data
{{ $('NodeName').item.json.field }}
{{ $('NodeName').first().json.field }}
{{ $('NodeName').last().json.field }}
{{ $('NodeName').all()[0].json.field }}

// Multiple items
{{ $items('NodeName') }}
{{ $items('NodeName').length }}

// Workflow context
{{ $workflow.id }}
{{ $workflow.name }}
{{ $execution.id }}
{{ $execution.mode }}

// Date/time
{{ $now }}
{{ $now.toISOString() }}
{{ $now.toLocaleString() }}
{{ $now.toFormat('yyyy-MM-dd') }}
{{ $today }}

// Binary data
{{ $binary.data }}

// Environment variables
{{ $env.VARIABLE_NAME }}

// Parameters
{{ $parameter.parameterName }}
```

### Conditional Logic

```javascript
// IF statement
{{ $json.field === 'value' ? 'yes' : 'no' }}

// Nested conditions
{{ $json.score >= 80 ? 'qualified' :
   $json.score >= 50 ? 'maybe' :
   'disqualified' }}

// Boolean checks
{{ $json.field ? 'exists' : 'missing' }}
{{ $json.field === true }}
{{ !$json.field }}
```

### String Operations

```javascript
// Concatenation
{{ $json.firstName + ' ' + $json.lastName }}

// Template literals (NOT supported directly - use concatenation)
{{ 'Hello, ' + $json.name + '!' }}

// String methods
{{ $json.email.toLowerCase() }}
{{ $json.name.trim() }}
{{ $json.text.includes('keyword') }}
{{ $json.url.startsWith('https://') }}
{{ $json.filename.endsWith('.pdf') }}
```

### Array Operations

```javascript
// Array methods
{{ $json.items.length }}
{{ $json.tags.join(', ') }}
{{ $json.scores.map(x => x * 2) }}
{{ $json.numbers.filter(x => x > 10) }}

// Accessing items
{{ $items('HTTP Request').length }}
{{ $items('HTTP Request')[0].json.status }}
```

### Date Formatting

```javascript
// ISO format
{{ $now.toISOString() }}
// Output: "2025-11-26T12:30:00.000Z"

// Locale string (Portuguese Brazil)
{{ $now.toLocaleString('pt-BR') }}
// Output: "26/11/2025 12:30:00"

// Custom format (using Luxon)
{{ $now.toFormat('yyyy-MM-dd') }}
{{ $now.toFormat('dd/MM/yyyy HH:mm') }}
{{ $now.toFormat('EEEE, dd MMMM yyyy', { locale: 'pt' }) }}
// Output: "terça-feira, 26 novembro 2025"

// Relative dates
{{ $today }}
{{ $now.plus({ days: 7 }).toFormat('yyyy-MM-dd') }}
{{ $now.minus({ hours: 2 }).toISO() }}
```

## 🚀 Workflow: Creating a New n8n Agent Prompt

### Step 1: Gather Requirements
Ask the user these clarifying questions (max 3):

1. **Agent Type & Purpose**:
   - "What is the primary function of this agent?" (SDR, support, data processing, API integration)
   - "Who is the end user?" (customers, internal team, system)

2. **Context & Integration**:
   - "What n8n nodes will feed data to this agent?" (need to document `{{ $json }}` inputs)
   - "What tools/APIs does the agent need to call?" (will go in Tools section)

3. **Business Rules** (if customer-facing):
   - "Any critical business rules?" (pricing, compliance, availability)
   - "Preferred tone?" (formal/informal, brand voice)

### Step 2: Select Template
Based on answers:
- B2C SDR → Use Template 1
- B2E Assistant → Use Template 2
- Data Processing → Use Template 3
- Custom → Start from scratch with CRITICS structure

### Step 3: Fill Out CRITICS Sections
Go section by section:

1. **Constraints**: Start with `{{ $now }}`, add CRÍTICO rules, define formats
2. **Role**: Define WHO and WHY
3. **Inputs**: Document all `{{ $json }}` variables from previous nodes
4. **Tools**: List available tools with parameters
5. **Instructions**: Write step-by-step workflow + decision trees
6. **Conclusions**: Define output structure with examples
7. **Solutions**: Cover error scenarios with recovery strategies

### Step 4: Add Conversational Influence (if customer-facing)
- Integrate Dale Carnegie principles (#1 Use Name, #4 Listen First)
- Add No-Go Sales language (permission-based, easy exit)
- Include NEPQ questions in Instructions
- Add Feel-Felt-Found for objections
- Apply AIDA or PAS framework to message structure

### Step 5: Validate & Test
Use the Prompt Audit Checklist:
- [ ] All CRITICS sections complete
- [ ] n8n syntax correct
- [ ] No contradictory instructions
- [ ] Examples are realistic
- [ ] Conversational flow makes sense (for customer-facing)

### Step 6: Deliver
Return the complete prompt in markdown format with:
- Clear section headers
- XML tags for structure
- Code blocks for examples
- Comments explaining complex logic

## 🎓 Common Mistakes & How to Avoid Them

### ❌ Mistake 1: Vague Constraints
**Bad**: "Seja profissional"
**Good**: "Use tratamento formal (Senhor/Senhora), evite gírias, máximo 150 palavras por resposta"

### ❌ Mistake 2: Missing {{ $now }}
**Bad**: Constraints without date reference
**Good**: `* A data de hoje é {{ $now }}. Use para cálculos temporais e referências de prazo`

### ❌ Mistake 3: Instructions Too Abstract
**Bad**: "Qualifique o lead"
**Good**: "Qualifique usando BANT: 1) Pergunte orçamento, 2) Confirme autoridade..."

### ❌ Mistake 4: No Error Handling
**Bad**: Only happy path in Instructions
**Good**: Solutions section with 5+ error scenarios and recovery strategies

### ❌ Mistake 5: Artificial Scarcity (Customer-Facing)
**Bad**: "Últimas vagas!" (quando não é verdade)
**Good**: Use scarcity ONLY when genuine, or focus on value instead

### ❌ Mistake 6: Forgetting Tool Documentation
**Bad**: "Use SearchAPI tool"
**Good**:
```markdown
1. SearchAPI - Busca informações externas
   * query (obrigatório) - Termo de busca
   * limit (opcional, default: 10) - Máximo de resultados
```

### ❌ Mistake 7: No Output Examples
**Bad**: "Retorne JSON estruturado"
**Good**: Show actual JSON example with all fields and types

### ❌ Mistake 8: Mixing Constraints with Instructions
**Bad**: Put workflow steps in Constraints section
**Good**: Constraints = rules/boundaries, Instructions = process/workflow

### ❌ Mistake 9: Overly Long Prompts
**Bad**: 2000+ line prompts with redundant information
**Good**: Concise, focused prompts (300-800 lines depending on complexity)

### ❌ Mistake 10: Not Testing n8n Variables
**Bad**: `{{ $json.field-name }}` (won't work with dashes)
**Good**: `{{ $json['field-name'] }}` or rename field to `field_name`

## 📚 Additional Resources

### n8n Documentation
- [n8n Expressions](https://docs.n8n.io/code-examples/expressions/)
- [Workflow Variables](https://docs.n8n.io/workflows/variables/)
- [Error Handling](https://docs.n8n.io/workflows/error-handling/)

### Conversational Influence
- Dale Carnegie: "How to Win Friends and Influence People"
- Chris Voss: "Never Split the Difference" (for advanced negotiation)
- Alex Hormozi: "$100M Offers" (for value stacking)

### Prompt Engineering
- Anthropic: [Prompt Engineering Guide](https://docs.anthropic.com/claude/docs/prompt-engineering)
- OpenAI: [Prompt Engineering Best Practices](https://platform.openai.com/docs/guides/prompt-engineering)

## 🎯 Quick Command Reference

When user says:
- **"Create prompt for [agent type]"** → Ask 2-3 clarifying questions, then use appropriate template
- **"Audit this prompt"** → Apply Prompt Audit Checklist, provide scorecard
- **"Add conversational influence"** → Integrate Dale Carnegie + No-Go + NEPQ
- **"Optimize for tokens"** → Reduce redundancy, use references, tighten language
- **"Fix n8n syntax"** → Validate all `{{ }}` expressions, check node references
- **"Add error handling"** → Expand Solutions section with 5+ scenarios

---

**Remember**: The goal is creating prompts that are:
- ✅ **Complete** (CRITICS covers everything)
- ✅ **Clear** (no ambiguity for AI or human readers)
- ✅ **Actionable** (step-by-step instructions)
- ✅ **Error-Resilient** (handles edge cases)
- ✅ **Conversationally Effective** (for customer-facing agents)
- ✅ **n8n-Native** (correct syntax and patterns)

Now you're ready to engineer world-class n8n AI agent prompts! 🚀
